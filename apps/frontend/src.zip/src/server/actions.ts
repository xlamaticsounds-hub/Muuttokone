'use server';

// Imports removed as part of bloat removal.
import { safeFormAction, createSuccessResult, createErrorResult } from '@/lib/form-helpers';
import {
  contactSchema,
  newsletterSchema,
  type ContactFormData,
  type NewsletterData,
} from '@/lib/schemas';

export async function submitContact(formData: FormData) {
  return safeFormAction(
    contactSchema,
    async (data: ContactFormData) => {

      try {
        // Use the unified API route instead of direct Directus calls
        const response = await fetch('/api/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'lead',
            data: {
              name: data.name,
              message: data.message,
              service_type: 'contact',
              source: 'website',
            }
          })
        });

        const result = await response.json();

        if (!result.success) {
          throw new Error(result.message || 'Submission failed');
        }

  // Logging removed as part of bloat cleanup.
        return createSuccessResult(undefined, 'Viesti lähetetty onnistuneesti!');
      } catch (error) {
  // Logging removed as part of bloat cleanup.
        return createErrorResult('Viestin lähetys epäonnistui. Yritä uudelleen.');
      }
    },
    formData,
  );
}

export async function subscribeNewsletter(formData: FormData) {
  return safeFormAction(
    newsletterSchema,
    async (data: NewsletterData) => {
  // Rate limiting removed as part of bloat cleanup.

      try {
        // TODO /API/SUBSCRIBE
        await fetch('/api/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: data.email,
            status: 'active',
            gdpr_consent: data.gdprConsent,
            source: 'website',
            subscribed_at: new Date().toISOString(),
          }),
        });

  // Logging removed as part of bloat cleanup.
        return createSuccessResult(undefined, 'Uutiskirje tilattu onnistuneesti!');
      } catch (error) {
  // Logging removed as part of bloat cleanup.
        return createErrorResult('Uutiskirjeen tilaus epäonnistui. Yritä uudelleen.');
      }
    },
    formData,
  );
}
